//
//  NumberGridApp.swift
//  NumberGrid
//
//  Created by Ming Xia on 3/3/22.
//

import SwiftUI

@main
struct NumberGridApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
